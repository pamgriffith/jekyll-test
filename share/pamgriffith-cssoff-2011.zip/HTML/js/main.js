$(document).ready(function () {
	// neater header backgrounds
	$('section h2').each(function () {
		var header = $(this);
		var text = header.find('span');
		if (text.length == 0) return;
		var divisor = 20;
		/*var w = parseInt(heading.css('width'));
		var remainder = w % divisor;
		w += (divisor - remainder);
		heading.css({'width':w,'display':'block'});*/
		var hw = parseInt(header.css('width'));
		var tw = parseInt(text.css('width'));
		var remainder = (hw - tw) % divisor;
		tw += remainder + 1;
		text.css({ width:tw, display:'block' });
	});
	
	// prettier select boxes
	/*$('.select-wrapper').each(function () {
		var wrapper = $(this);
		var select = wrapper.find('select');
		var arrow = $('<span class="arrow"></span>');
		wrapper.append(arrow);
		arrow.click(function (event) {
			event.preventDefault();
			select.click(); // does not work
		});
	});*/
	
	// obstacles
	var obstacle_list = $('#obstacles li');
	var large_obstacles = $('#obstacles article');
	obstacle_list.find('a').click(function (event) {
		var link = $(this);
		var sm = link.closest('li');
		var lg = $(link.attr('href'));
		obstacle_list.add(large_obstacles).removeClass('selected').addClass('unselected');
		sm.add(lg).removeClass('unselected').addClass('selected');
		event.preventDefault();
	});
	$(obstacle_list.get(0)).find('a').click();
});